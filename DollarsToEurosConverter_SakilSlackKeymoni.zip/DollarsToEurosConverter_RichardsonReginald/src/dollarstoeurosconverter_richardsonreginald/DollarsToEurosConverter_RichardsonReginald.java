/**
 *
 * @author richardr7495
 */
package dollarstoeurosconverter_richardsonreginald;
import java.util.Scanner;
public class DollarsToEurosConverter_RichardsonReginald {
    public static void main(String[] args) {
        System.out.println("Welcome to the Dollars to Euros Converter.\n");
        Scanner keyboard = new Scanner(System.in);
        System.out.print("How many dollars do you want to convert? ");
        double dollars = keyboard.nextDouble();
        System.out.print("What is the euros-per-dollar exchange rate? ");
        double eurosPerDollar = keyboard.nextDouble();
        double euros = dollars * eurosPerDollar;
        System.out.println(dollars + " dollars => " + euros + "euros.");
        // TODO code application logic here
    }
}
